#ifndef MOTEUR1_H
#define MOTEUR1_H


class Moteur1
{
public:
    Moteur1();
    ~Moteur1();
};

#endif // MOTEUR1_H
