#include "partition.h"

Partition::Partition()
{

}

Partition::~Partition()
{

}

