#include "firstload.h"

FirstLoad::FirstLoad()
{

}

FirstLoad::~FirstLoad()
{

}

