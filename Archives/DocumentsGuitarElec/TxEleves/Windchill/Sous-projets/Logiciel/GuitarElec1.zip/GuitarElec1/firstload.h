#ifndef FIRSTLOAD_H
#define FIRSTLOAD_H


class FirstLoad
{
public:
    FirstLoad();
    ~FirstLoad();
};

#endif // FIRSTLOAD_H
