#ifndef PARTITION_H
#define PARTITION_H


class Partition
{
public:
    Partition();
    ~Partition();
};

#endif // PARTITION_H
