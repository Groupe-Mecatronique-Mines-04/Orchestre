#include "manual.h"

Manual::Manual()
{

}

Manual::~Manual()
{

}

