#ifndef MANUAL_H
#define MANUAL_H


class Manual
{
public:
    Manual();
    ~Manual();
};

#endif // MANUAL_H
