#include "moteur1.h"

Moteur1::Moteur1()
{

}

Moteur1::~Moteur1()
{

}

